# CineIA — recomendações de filmes, séries e streaming com IA

Um app em português onde a pessoa conversa com um assistente e recebe recomendações
de filmes e séries, com pôsteres, sinopse, nota, onde assistir, favoritos e lista
para assistir salvos na conta.

## Telas

1. **Início (/)** — apresentação curta, filtros de plataforma, botão para começar
   a conversar e um quiz rápido de humor.
2. **Assistente (/chat)** — um bate-papo contínuo. A pessoa escreve o que quer
   ("algo leve pra hoje à noite"), o assistente responde e mostra cards de
   recomendação dentro da conversa.
3. **Quiz de humor (/quiz)** — 4 a 5 perguntas rápidas (humor, tempo disponível,
   com quem vai assistir, gêneros preferidos, plataformas). No final, envia tudo
   para o assistente e mostra as sugestões.
4. **Minha lista (/minha-lista)** — duas abas: Favoritos e Quero assistir.
5. **Entrar (/auth)** — criar conta e entrar com e-mail e senha.

## Como funcionam as recomendações

O assistente devolve, junto do texto, uma lista estruturada de títulos com: nome,
ano, tipo (filme/série), gêneros, sinopse curta, nota de 0 a 10, motivo da
indicação e onde assistir (Netflix, Prime Video, Disney+, Max, Apple TV+, Globoplay,
Paramount+). Cada título ganha um pôster gerado automaticamente e guardado, para
que o mesmo título não seja gerado duas vezes. Enquanto o pôster não existe, o card
mostra uma capa provisória com o nome do título.

Os filtros de plataforma escolhidos no início e no quiz são enviados ao assistente,
que só indica títulos disponíveis nessas plataformas.

## Contas e dados salvos

Login por e-mail e senha. Ficam salvos na conta: o histórico da conversa, os
favoritos e a lista para assistir. Cada pessoa vê apenas os seus dados.

## Aparência

Visual escuro de cinema, sem cara de modelo genérico: fundo grafite profundo,
destaque em âmbar quente, tipografia com títulos condensados e texto limpo, cards
de pôster com leve elevação e brilho na borda ao passar o mouse. Todo o texto da
interface em português do Brasil.

## Detalhes técnicos

- Lovable Cloud: autenticação por e-mail/senha e tabelas `chat_messages`,
  `titles` (cache de títulos + caminho do pôster), `list_items`
  (favorito/watchlist), todas com RLS por `auth.uid()` e GRANTs explícitos.
- Rota de streaming `src/routes/api/chat.ts` com AI SDK; modelo padrão
  `openai/gpt-6-astra` via Responses API, streaming obrigatório, chave só no
  servidor. Recomendações vêm por tool call com schema estrito e são renderizadas
  como cards.
- Persistência das mensagens em `onFinish` do `toUIMessageStreamResponse`.
- UI de chat com AI Elements (conversation, message, prompt-input, shimmer, tool).
- Pôsteres gerados no servidor sob demanda e guardados no Storage, referenciados
  pela tabela `titles`.
- Favoritos/watchlist via `createServerFn` autenticadas; leituras via TanStack Query.
- `head()` próprio em cada rota com título e descrição em português.

## Ordem de execução

1. Ativar Lovable Cloud + migração (tabelas, RLS, GRANTs, bucket de pôsteres).
2. Design system escuro + layout base e página inicial.
3. Login/cadastro e proteção das rotas com dados do usuário.
4. Rota de chat com IA + tool de recomendações + persistência.
5. Cards de recomendação, geração de pôsteres, botões de favorito/watchlist.
6. Quiz de humor alimentando o assistente.
7. Página Minha lista.
8. Verificação no navegador: conversar, favoritar, recarregar e conferir.
