<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Estrela-guia

Espectadores curtem filmes, séries, animes e desenhos que querem assistir

## Métrica

Total de horas de vídeo assistidas no player por semana
