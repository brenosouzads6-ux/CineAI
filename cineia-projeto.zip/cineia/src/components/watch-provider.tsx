import { createContext, useCallback, useContext, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { MediaPlayer } from "@/components/media-player";
import type { MediaItem } from "@/lib/catalog";
import { listProgress } from "@/lib/continue-watching";

type PlayRequest = { item: MediaItem; episodeIndex: number; position?: number };

const WatchContext = createContext<{ play: (item: MediaItem, episodeIndex?: number, position?: number) => void }>({
  play: () => {},
});

export function WatchProvider({ children }: { children: ReactNode }) {
  const [current, setCurrent] = useState<PlayRequest | null>(null);

  const play = useCallback((item: MediaItem, episodeIndex?: number, position?: number) => {
    if (!item.playable) {
      toast(item.title, { description: item.unavailableNote });
      return;
    }
    let index = episodeIndex;
    if (index === undefined) {
      // Séries: abre no último episódio que a pessoa estava vendo.
      const last = listProgress().find((p) => p.itemId === item.id);
      index = last?.episodeIndex ?? 0;
    }
    setCurrent({ item, episodeIndex: index, ...(position !== undefined ? { position } : {}) });
  }, []);

  return (
    <WatchContext.Provider value={{ play }}>
      {children}
      {current ? (
        <MediaPlayer
          key={`${current.item.id}-${current.episodeIndex}`}
          item={current.item}
          startEpisodeIndex={current.episodeIndex}
          {...(current.position !== undefined ? { startPosition: current.position } : {})}
          onClose={() => setCurrent(null)}
        />
      ) : null}
    </WatchContext.Provider>
  );
}

export const useWatch = () => useContext(WatchContext);
