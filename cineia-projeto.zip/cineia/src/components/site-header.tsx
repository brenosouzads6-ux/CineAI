import { Link, useRouterState } from "@tanstack/react-router";
import { Clapperboard, Lock } from "lucide-react";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Início" },
  { to: "/filmes", label: "Filmes" },
  { to: "/series", label: "Séries" },
  { to: "/animes", label: "Animes" },
  { to: "/desenhos", label: "Desenhos" },
] as const;

export function SiteHeader() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <header className="sticky top-0 z-40 border-b border-border/70 bg-background/85 backdrop-blur">
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center gap-4 px-4">
        <Link to="/" className="flex shrink-0 items-center gap-2">
          <Clapperboard className="size-5 text-primary" />
          <span className="font-display text-xl uppercase tracking-widest">CineIA</span>
        </Link>
        <nav className="-mr-4 flex items-center gap-1 overflow-x-auto pr-4">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "shrink-0 rounded-md px-3 py-2 text-sm text-muted-foreground transition-colors hover:text-foreground",
                pathname === item.to && "bg-secondary text-foreground",
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <Link
          to="/admin"
          aria-label="Painel do dono"
          className={cn(
            "ml-auto flex shrink-0 items-center gap-1 rounded-md px-3 py-2 text-sm text-muted-foreground hover:text-foreground",
            pathname === "/admin" && "bg-secondary text-foreground",
          )}
        >
          <Lock className="size-4" />
          <span className="hidden sm:inline">Painel</span>
        </Link>
      </div>
    </header>
  );
}
