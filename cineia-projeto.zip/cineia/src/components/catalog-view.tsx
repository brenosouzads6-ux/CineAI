import { useCallback, useEffect, useState } from "react";
import { ChevronLeft, ChevronRight, Lock, Play, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { formatClock, formatRuntime } from "@/lib/media";
import { KIND_LABEL, episodeCount, useCatalog, type MediaItem, type Row } from "@/lib/catalog";
import { removeProgress, useContinueWatching } from "@/lib/continue-watching";
import { useWatch } from "@/components/watch-provider";

const meta = (item: MediaItem) => {
  const count = episodeCount(item);
  if (count) return `${item.year} · ${count} episódio${count > 1 ? "s" : ""}`;
  if (item.runtimeMin) return `${item.year} · ${formatRuntime(item.runtimeMin)}`;
  return [item.year || null, item.genres.join(", ") || null].filter(Boolean).join(" · ");
};

export function PosterCard({ item, className }: { item: MediaItem; className?: string }) {
  const { play } = useWatch();
  return (
    <article className={cn("overflow-hidden rounded-lg border border-border/70 bg-card", className)}>
      <button
        type="button"
        onClick={() => play(item)}
        className="group relative block w-full text-left"
        aria-label={item.playable ? `Assistir ${item.title}` : `${item.title} (indisponível)`}
      >
        <div className="aspect-[3/4] overflow-hidden bg-secondary">
          <img
            src={item.posterUrl}
            alt={`Capa de ${item.title}`}
            loading="lazy"
            className="size-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
        </div>
        <span className="absolute left-2 top-2 rounded bg-background/80 px-2 py-0.5 text-[10px] uppercase tracking-wide">
          {KIND_LABEL[item.kind]}
        </span>
        <span className="absolute inset-0 flex items-center justify-center bg-background/60 opacity-0 transition-opacity group-hover:opacity-100 group-focus-visible:opacity-100">
          <span className="flex size-12 items-center justify-center rounded-full bg-primary text-primary-foreground">
            {item.playable ? <Play className="size-5" /> : <Lock className="size-5" />}
          </span>
        </span>
      </button>
      <div className="space-y-1 p-3">
        <h3 className="font-display text-base leading-tight">{item.title}</h3>
        <p className="text-[11px] uppercase tracking-wide text-muted-foreground">{meta(item)}</p>
        <p className="line-clamp-3 text-xs text-muted-foreground">{item.synopsis}</p>
        {!item.playable ? <p className="text-[11px] text-primary">Em breve para assistir</p> : null}
      </div>
    </article>
  );
}

export function MediaRow({ row }: { row: Row }) {
  if (!row.items.length) return null;
  return (
    <section aria-label={row.title}>
      <h2 className="font-display text-2xl uppercase tracking-wide">{row.title}</h2>
      <p className="mt-1 text-sm text-muted-foreground">{row.subtitle}</p>
      <div className="-mx-4 mt-4 flex snap-x snap-mandatory gap-4 overflow-x-auto px-4 pb-3">
        {row.items.map((item) => (
          <PosterCard key={item.id} item={item} className="w-[210px] shrink-0 snap-start" />
        ))}
      </div>
    </section>
  );
}

export function CatalogGrid({ items }: { items: MediaItem[] }) {
  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
      {items.map((item) => (
        <PosterCard key={item.id} item={item} />
      ))}
    </div>
  );
}

export function FeaturedHero({ items }: { items: MediaItem[] }) {
  const { play } = useWatch();
  const [index, setIndex] = useState(0);
  const total = items.length;
  const current = items[index];
  const go = useCallback((step: number) => setIndex((i) => (i + step + total) % total), [total]);

  useEffect(() => {
    if (total < 2) return;
    const timer = window.setInterval(() => setIndex((i) => (i + 1) % total), 8000);
    return () => window.clearInterval(timer);
  }, [total]);

  if (!current) return null;

  return (
    <section aria-label="Destaques" className="relative mt-6 overflow-hidden rounded-xl border border-border/70">
      <div className="relative h-[420px] w-full sm:h-[460px]">
        <img key={current.id} src={current.posterUrl} alt={`Cena de ${current.title}`} className="size-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-background/20" />
        <div className="absolute inset-x-0 bottom-0 max-w-2xl p-6 sm:p-8">
          <span className="text-xs uppercase tracking-[0.2em] text-primary">
            Em destaque · {KIND_LABEL[current.kind]}
          </span>
          <h2 className="mt-2 font-display text-4xl uppercase leading-none sm:text-5xl">{current.title}</h2>
          <p className="mt-2 text-xs uppercase tracking-wide text-muted-foreground">{meta(current)}</p>
          <p className="mt-3 max-w-xl text-sm text-muted-foreground">{current.tagline ?? current.synopsis}</p>
          <div className="mt-5 flex flex-wrap items-center gap-3">
            <Button size="lg" onClick={() => play(current)}>
              <Play className="size-4" />
              Assistir agora
            </Button>
            {total > 1 ? (
              <div className="flex items-center gap-2">
                <Button variant="outline" size="icon-sm" className="min-h-11 min-w-11" aria-label="Destaque anterior" onClick={() => go(-1)}>
                  <ChevronLeft className="size-4" />
                </Button>
                <Button variant="outline" size="icon-sm" className="min-h-11 min-w-11" aria-label="Próximo destaque" onClick={() => go(1)}>
                  <ChevronRight className="size-4" />
                </Button>
              </div>
            ) : null}
          </div>
          <div className="mt-5 flex gap-2">
            {items.map((item, i) => (
              <button
                key={item.id}
                type="button"
                aria-label={`Ver destaque ${item.title}`}
                aria-current={i === index}
                onClick={() => setIndex(i)}
                className={cn("h-1.5 w-8 rounded-full transition-colors", i === index ? "bg-primary" : "bg-muted")}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

export function ContinueWatchingRow({ kind }: { kind?: MediaItem["kind"] }) {
  const { play } = useWatch();
  const progress = useContinueWatching();
  const { items } = useCatalog();
  const entries = progress
    .map((p) => ({ p, item: items.find((i) => i.id === p.itemId) }))
    .filter((e): e is { p: (typeof progress)[number]; item: MediaItem } => Boolean(e.item))
    .filter((e) => !kind || e.item.kind === kind);

  if (!entries.length) return null;

  return (
    <section aria-label="Continuar assistindo">
      <h2 className="font-display text-2xl uppercase tracking-wide">Continuar assistindo</h2>
      <p className="mt-1 text-sm text-muted-foreground">Volte exatamente de onde parou</p>
      <div className="-mx-4 mt-4 flex snap-x gap-4 overflow-x-auto px-4 pb-3">
        {entries.map(({ p, item }) => {
          const ep = item.episodes?.[p.episodeIndex];
          const pct = Math.min(100, Math.round((p.position / p.duration) * 100));
          return (
            <article key={p.key} className="relative w-[280px] shrink-0 snap-start overflow-hidden rounded-lg border border-border/70 bg-card">
              <button type="button" className="group block w-full text-left" onClick={() => play(item, p.episodeIndex, p.position)}>
                <div className="relative aspect-video overflow-hidden bg-secondary">
                  <img src={item.posterUrl} alt={`Capa de ${item.title}`} loading="lazy" className="size-full object-cover" />
                  <span className="absolute inset-0 flex items-center justify-center bg-background/40 opacity-0 transition-opacity group-hover:opacity-100">
                    <Play className="size-8 text-primary" />
                  </span>
                  <div className="absolute inset-x-0 bottom-0 h-1 bg-muted">
                    <div className="h-full bg-primary" style={{ width: `${pct}%` }} />
                  </div>
                </div>
                <div className="p-3">
                  <h3 className="truncate font-display text-base">{item.title}</h3>
                  <p className="truncate text-xs text-muted-foreground">
                    {ep ? `T${ep.season}:E${ep.number} ${ep.title} · ` : ""}
                    {formatClock(p.position)} de {formatClock(p.duration)}
                  </p>
                </div>
              </button>
              <Button
                variant="ghost"
                size="icon-sm"
                className="absolute right-1 top-1 bg-background/70"
                aria-label={`Remover ${item.title} de continuar assistindo`}
                onClick={() => removeProgress(p.key)}
              >
                <X className="size-4" />
              </Button>
            </article>
          );
        })}
      </div>
    </section>
  );
}
