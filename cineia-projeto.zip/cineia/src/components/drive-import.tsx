import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Check, ChevronDown, Folder, HardDriveDownload, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { KIND_LABEL, useCatalog, type Kind } from "@/lib/catalog";
import { listDriveFiles, listDriveFolders, importDriveFile, type DriveFile } from "@/lib/drive.functions";
import { autofillTitle } from "@/lib/autofill.functions";
import { uploadFile } from "@/lib/upload";
import { useServerFn } from "@tanstack/react-start";

const formatSize = (bytes: number) => {
  if (!bytes) return "—";
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(0)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)} GB`;
};

const select = "h-10 w-full rounded-md border border-input bg-background px-3 text-sm";

export function DriveImport() {
  const qc = useQueryClient();
  const { items } = useCatalog();
  const autofill = useServerFn(autofillTitle);

  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [folderId, setFolderId] = useState<string | null>(null);
  const [showAll, setShowAll] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  const [target, setTarget] = useState<string>("new");
  const [kind, setKind] = useState<Kind>("filme");
  const [titulo, setTitulo] = useState("");
  const [ano, setAno] = useState("");
  const [generos, setGeneros] = useState("");
  const [sinopse, setSinopse] = useState("");
  const [capa, setCapa] = useState<File | null>(null);
  const [destaque, setDestaque] = useState(false);
  const [temporada, setTemporada] = useState("1");

  const [filling, setFilling] = useState(false);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState("");

  const foldersQuery = useQuery({
    queryKey: ["drive-folders"],
    enabled: open,
    staleTime: 1000 * 60 * 10,
    queryFn: () => listDriveFolders(),
  });

  const filesQuery = useQuery({
    queryKey: ["drive-files", folderId, showAll],
    enabled: open && !!folderId,
    staleTime: 1000 * 60 * 5,
    queryFn: () => listDriveFiles({ data: { folderId: folderId!, all: showAll } }),
  });

  const folders = (foldersQuery.data?.folders ?? []).filter((f) =>
    f.name.toLowerCase().includes(search.trim().toLowerCase()),
  );
  const files: DriveFile[] = filesQuery.data?.files ?? [];
  const chosen = files.filter((f) => selectedIds.has(f.id));

  // IA preenche nome, ano, gênero e sinopse a partir do primeiro arquivo escolhido.
  useEffect(() => {
    if (target !== "new" || filling || titulo) return;
    const first = chosen[0];
    if (!first) return;
    let active = true;
    setFilling(true);
    autofill({ data: { fileName: first.name, kind: KIND_LABEL[kind] } })
      .then((r) => {
        if (!active) return;
        setTitulo((t) => t || r.title);
        setAno((a) => a || (r.year ? String(r.year) : ""));
        setGeneros((g) => g || r.genres.join(", "));
        setSinopse((s) => s || r.synopsis);
        toast.success("Nome, gênero e sinopse preenchidos. Confira antes de importar.");
      })
      .catch((err) => {
        if (!active) return;
        setTitulo((t) => t || first.name.replace(/\.[^.]+$/, "").replace(/[._-]+/g, " ").trim());
        toast.error("Não deu para preencher tudo", { description: err instanceof Error ? err.message : undefined });
      })
      .finally(() => active && setFilling(false));
    return () => {
      active = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedIds, files, target, kind]);

  const toggle = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const doImport = async () => {
    if (!chosen.length) {
      toast.error("Escolha pelo menos um arquivo do Drive.");
      return;
    }
    if (target === "new" && !titulo.trim()) {
      toast.error("Dê um nome ao novo título.");
      return;
    }
    setBusy(true);
    try {
      let titleId = target;
      let start = 1;
      let season = Math.max(1, Number(temporada) || 1);
      let effectiveKind: Kind = kind;
      if (target === "new") {
        let posterPath: string | null = null;
        if (capa && capa.size) posterPath = await uploadFile(capa, "capas");
        const { data: inserted, error } = await supabase
          .from("catalog_titles")
          .insert({
            kind,
            title: titulo.trim(),
            year: ano ? Number(ano) : null,
            genres: generos.split(",").map((g) => g.trim()).filter(Boolean),
            synopsis: sinopse.trim(),
            poster_url: posterPath,
            featured: destaque,
          })
          .select("id")
          .single();
        if (error) throw error;
        titleId = inserted.id;
      } else {
        const existing = items.find((i) => i.id === target);
        effectiveKind = (existing?.kind as Kind) ?? "filme";
        const same = (existing?.episodes ?? []).filter((ep) => ep.season === season);
        start = same.length ? Math.max(...same.map((ep) => ep.number)) + 1 : 1;
        if (existing?.kind === "filme") season = 1;
      }
      const multi = chosen.length > 1 || effectiveKind !== "filme";
      for (const [i, f] of chosen.entries()) {
        setProgress(`Importando ${i + 1} de ${chosen.length}: ${f.name}…`);
        await importDriveFile({
          data: {
            fileId: f.id,
            fileName: f.name,
            mimeType: f.mimeType,
            titleId,
            season,
            episodeNumber: start + i,
            episodeName: multi ? f.name.replace(/\.[^.]+$/, "") : "",
          },
        });
      }
      toast.success(chosen.length === 1 ? "Arquivo importado do Drive" : `${chosen.length} arquivos importados do Drive`);
      setSelectedIds(new Set());
      if (target === "new") {
        setTitulo("");
        setAno("");
        setGeneros("");
        setSinopse("");
        setCapa(null);
        setDestaque(false);
      }
      await qc.invalidateQueries({ queryKey: ["catalog"] });
    } catch (err) {
      toast.error("Não foi possível importar", { description: err instanceof Error ? err.message : String(err) });
    } finally {
      setBusy(false);
      setProgress("");
    }
  };

  return (
    <section className="mt-4 rounded-lg border border-border/70 bg-card">
      <button
        type="button"
        className="flex w-full items-center justify-between p-4 text-left"
        onClick={() => setOpen((o) => !o)}
      >
        <span className="flex items-center gap-2 font-display text-2xl uppercase tracking-wide">
          <HardDriveDownload className="size-5 text-primary" /> Importar do Drive
        </span>
        <ChevronDown className={`size-5 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>

      {open ? (
        <div className="space-y-4 border-t border-border/70 p-4">
          {folderId === null ? (
            <div className="space-y-2">
              <Label htmlFor="drive-busca">Escolha a pasta do seu Drive</Label>
              <Input
                id="drive-busca"
                placeholder="Procurar pasta…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
              <ul className="max-h-60 divide-y divide-border/70 overflow-y-auto rounded-md border border-border/70">
                {foldersQuery.isLoading ? (
                  <li className="flex items-center gap-2 p-3 text-sm text-muted-foreground">
                    <Loader2 className="size-4 animate-spin" /> Abrindo seu Drive…
                  </li>
                ) : null}
                {foldersQuery.isError ? (
                  <li className="p-3 text-sm text-destructive">
                    Não deu para abrir o Drive agora. Tente de novo.
                  </li>
                ) : null}
                {folders.map((f) => (
                  <li key={f.id}>
                    <button
                      type="button"
                      className="flex w-full items-center gap-2 p-3 text-left text-sm hover:bg-muted/40"
                      onClick={() => setFolderId(f.id)}
                    >
                      <Folder className="size-4 shrink-0 text-primary" />
                      <span className="truncate">{f.name}</span>
                    </button>
                  </li>
                ))}
                {!foldersQuery.isLoading && !folders.length ? (
                  <li className="p-3 text-sm text-muted-foreground">Nenhuma pasta com esse nome.</li>
                ) : null}
              </ul>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between gap-2">
                <button
                  type="button"
                  className="text-sm text-muted-foreground underline underline-offset-4"
                  onClick={() => {
                    setFolderId(null);
                    setSelectedIds(new Set());
                  }}
                >
                  ← Trocar pasta
                </button>
                <label className="flex items-center gap-2 text-xs text-muted-foreground">
                  <input
                    type="checkbox"
                    checked={showAll}
                    onChange={(e) => {
                      setShowAll(e.target.checked);
                      setSelectedIds(new Set());
                    }}
                  />
                  Mostrar todos os tipos de arquivo
                </label>
              </div>

              {filesQuery.isLoading ? (
                <p className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Loader2 className="size-4 animate-spin" /> Lendo os arquivos da pasta…
                </p>
              ) : null}
              {filesQuery.isError ? (
                <p className="text-sm text-destructive">Não deu para ler os arquivos agora. Tente de novo.</p>
              ) : null}
              {!filesQuery.isLoading && !files.length ? (
                <p className="text-sm text-muted-foreground">
                  Nenhum arquivo de vídeo ou MP3 nesta pasta. Ative “mostrar todos os tipos” se o arquivo estiver com
                  outro nome.
                </p>
              ) : null}

              {files.length ? (
                <>
                  <div className="flex items-center justify-between">
                    <p className="text-sm">{files.length} arquivo(s) na pasta</p>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() =>
                        setSelectedIds((prev) => (prev.size === files.length ? new Set() : new Set(files.map((f) => f.id))))
                      }
                    >
                      {chosen.length === files.length ? "Desmarcar todos" : "Marcar todos"}
                    </Button>
                  </div>
                  <ul className="max-h-72 divide-y divide-border/70 overflow-y-auto rounded-md border border-border/70">
                    {files.map((f) => (
                      <li key={f.id}>
                        <button
                          type="button"
                          className="flex w-full items-center gap-3 p-3 text-left hover:bg-muted/40"
                          onClick={() => toggle(f.id)}
                        >
                          <span
                            className={`flex size-5 shrink-0 items-center justify-center rounded border ${
                              selectedIds.has(f.id) ? "border-primary bg-primary text-primary-foreground" : "border-border"
                            }`}
                          >
                            {selectedIds.has(f.id) ? <Check className="size-3.5" /> : null}
                          </span>
                          <span className="min-w-0 flex-1">
                            <span className="block truncate text-sm">{f.name}</span>
                            <span className="block text-xs text-muted-foreground">
                              {formatSize(f.size)}
                              {f.mimeType.startsWith("audio/") ? " · áudio" : f.mimeType.startsWith("video/") ? " · vídeo" : ""}
                            </span>
                          </span>
                        </button>
                      </li>
                    ))}
                  </ul>
                </>
              ) : null}

              {chosen.length ? (
                <div className="space-y-4">
                  <div className="space-y-1">
                    <Label>Adicionar a</Label>
                    <select className={select} value={target} onChange={(e) => setTarget(e.target.value)}>
                      <option value="new">Novo título</option>
                      {items.map((i) => (
                        <option key={i.id} value={i.id}>
                          Mais episódios em: {i.title} ({KIND_LABEL[i.kind]})
                        </option>
                      ))}
                    </select>
                  </div>

                  {target === "new" ? (
                    <>
                      <div className="grid gap-3 sm:grid-cols-2">
                        <div className="space-y-1">
                          <Label>Aba</Label>
                          <select className={select} value={kind} onChange={(e) => setKind(e.target.value as Kind)}>
                            {(Object.keys(KIND_LABEL) as Kind[]).map((k) => (
                              <option key={k} value={k}>
                                {KIND_LABEL[k]}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="space-y-1">
                          <Label htmlFor="drive-ano">Ano</Label>
                          <Input id="drive-ano" type="number" min={1880} max={2100} value={ano} onChange={(e) => setAno(e.target.value)} />
                        </div>
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="drive-titulo">Título</Label>
                        <Input id="drive-titulo" value={titulo} onChange={(e) => setTitulo(e.target.value)} />
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="drive-generos">Gêneros (separados por vírgula)</Label>
                        <Input id="drive-generos" value={generos} onChange={(e) => setGeneros(e.target.value)} />
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="drive-sinopse">Sinopse</Label>
                        <Textarea id="drive-sinopse" rows={3} value={sinopse} onChange={(e) => setSinopse(e.target.value)} />
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="drive-capa">Capa (imagem, opcional)</Label>
                        <Input
                          id="drive-capa"
                          type="file"
                          accept="image/*"
                          onChange={(e) => setCapa(e.target.files?.[0] ?? null)}
                        />
                      </div>
                      <label className="flex items-center gap-2 text-sm">
                        <input type="checkbox" checked={destaque} onChange={(e) => setDestaque(e.target.checked)} /> Mostrar nos
                        destaques
                      </label>
                    </>
                  ) : null}

                  <div className="grid gap-3 sm:grid-cols-[120px_1fr]">
                    <div className="space-y-1">
                      <Label htmlFor="drive-temporada">Temporada</Label>
                      <Input
                        id="drive-temporada"
                        type="number"
                        min={1}
                        value={temporada}
                        onChange={(e) => setTemporada(e.target.value)}
                      />
                    </div>
                  </div>

                  {filling ? <p className="text-xs text-primary">Preenchendo nome, gênero e sinopse com IA…</p> : null}
                  {progress ? <p className="text-xs text-muted-foreground">{progress}</p> : null}

                  <Button type="button" className="w-full" disabled={busy || filling} onClick={doImport}>
                    <HardDriveDownload className="size-4" />
                    {busy ? "Importando…" : `Importar ${chosen.length} arquivo(s)`}
                  </Button>
                  <p className="text-xs text-muted-foreground">
                    Os arquivos são copiados do Drive para o acervo do app. Isso pode demorar em arquivos grandes — deixe
                    esta página aberta.
                  </p>
                </div>
              ) : null}
            </>
          )}
        </div>
      ) : null}
    </section>
  );
}
