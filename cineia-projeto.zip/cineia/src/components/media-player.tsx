import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Captions, CaptionsOff, ListVideo, Maximize, Minimize, Settings, SkipForward, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { defaultQuality, formatClock, formatRuntime, qualitiesFor, subtitlesFor } from "@/lib/media";
import type { MediaItem } from "@/lib/catalog";
import { getProgress, saveProgress } from "@/lib/continue-watching";

type MediaPlayerProps = {
  item: MediaItem;
  /** Episódio inicial (séries, animes e desenhos). */
  startEpisodeIndex?: number;
  /** Segundo em que a reprodução deve começar. */
  startPosition?: number;
  onClose: () => void;
};

/** A faixa corresponde ao idioma escolhido (pt-BR ou en)? */
const trackMatches = (track: TextTrack, lang: "off" | "pt" | "en") =>
  lang !== "off" && (track.language ?? "").toLowerCase().startsWith(lang);

export function MediaPlayer({ item, startEpisodeIndex = 0, startPosition, onClose }: MediaPlayerProps) {
  const episodes = item.episodes ?? [];
  const [episodeIndex, setEpisodeIndex] = useState(startEpisodeIndex);
  const episode = episodes[episodeIndex];
  const archiveId = item.archiveId ?? episode?.archiveId ?? "";

  const directUrl = episode?.mediaUrl ?? item.mediaUrl;
  const isAudio = (episode?.mediaType ?? item.mediaType) === "audio";
  const qualities = useMemo(
    () => (directUrl ? [{ label: "Original", url: directUrl, height: 0 }] : qualitiesFor(archiveId)),
    [archiveId, directUrl],
  );
  const [qualityLabel, setQualityLabel] = useState(() => defaultQuality(qualities)?.label ?? "");
  const quality = qualities.find((q) => q.label === qualityLabel) ?? qualities[0];

  const subtitles = useMemo(() => subtitlesFor(archiveId), [archiveId]);
  const subtitleOptions = useMemo(
    () => [
      ...(subtitles.pt ? [{ value: "pt" as const, label: "Português (BR)" }] : []),
      ...(subtitles.en ? [{ value: "en" as const, label: "Inglês" }] : []),
    ],
    [subtitles.pt, subtitles.en],
  );
  const [subtitleLang, setSubtitleLang] = useState<"off" | "pt" | "en">("off");
  const [showEpisodes, setShowEpisodes] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [failed, setFailed] = useState(false);

  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  /** Posição a aplicar quando o vídeo carregar (retomada ou troca de qualidade). */
  const seekToRef = useRef<number>(0);
  const lastSavedRef = useRef(0);

  const runtimeMin = episode?.runtimeMin ?? item.runtimeMin ?? 0;
  const heading = episode
    ? `${item.title} — T${episode.season}:E${episode.number} ${episode.title}`
    : item.title;
  const nextEpisode = episodes[episodeIndex + 1];

  // Ao abrir ou trocar de episódio, define qualidade padrão e ponto de retomada.
  useEffect(() => {
    const list = qualities;
    setQualityLabel(defaultQuality(list)?.label ?? "");
    const saved = getProgress(item.id, archiveId);
    seekToRef.current = startPosition ?? saved?.position ?? 0;
    setFailed(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [archiveId, item.id]);

  const persist = useCallback(() => {
    const video = videoRef.current;
    if (!video || !archiveId || !video.duration) return;
    saveProgress({
      itemId: item.id,
      archiveId,
      episodeIndex,
      position: video.currentTime,
      duration: video.duration,
    });
  }, [archiveId, episodeIndex, item.id]);

  const toggleFullscreen = useCallback(() => {
    const el = containerRef.current;
    if (!el) return;
    if (document.fullscreenElement) {
      void document.exitFullscreen();
    } else {
      void el.requestFullscreen?.();
    }
  }, []);

  const close = useCallback(() => {
    persist();
    onClose();
  }, [onClose, persist]);

  useEffect(() => {
    const onFsChange = () => setIsFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener("fullscreenchange", onFsChange);

    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape" && !document.fullscreenElement) close();
      if (event.key === "f" || event.key === "F") toggleFullscreen();
    };
    document.addEventListener("keydown", onKey);

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    return () => {
      document.removeEventListener("fullscreenchange", onFsChange);
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = previousOverflow;
    };
  }, [close, toggleFullscreen]);

  // Guarda o progresso ao fechar a aba ou desmontar.
  useEffect(() => {
    const onHide = () => persist();
    window.addEventListener("pagehide", onHide);
    return () => {
      window.removeEventListener("pagehide", onHide);
      persist();
    };
  }, [persist]);

  // Liga a faixa de legenda escolhida e desliga as outras.
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    for (const track of Array.from(video.textTracks)) {
      track.mode = trackMatches(track, subtitleLang) ? "showing" : "hidden";
    }
  }, [subtitleLang, subtitles.pt, subtitles.en, quality?.url]);

  const toggleSubtitles = () => {
    if (subtitleLang !== "off") {
      setSubtitleLang("off");
      return;
    }
    setSubtitleLang(subtitles.pt ? "pt" : subtitles.en ? "en" : "off");
  };

  const changeQuality = (label: string) => {
    const video = videoRef.current;
    seekToRef.current = video?.currentTime ?? 0;
    setQualityLabel(label);
  };

  const goToEpisode = (index: number) => {
    persist();
    seekToRef.current = 0;
    setEpisodeIndex(index);
    setShowEpisodes(false);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col bg-black/95 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label={`Assistindo ${heading}`}
    >
      <div className="flex items-start gap-3 px-4 py-3">
        <div className="min-w-0">
          <h2 className="truncate font-display text-lg uppercase tracking-wide text-foreground">{heading}</h2>
          <p className="truncate text-xs text-muted-foreground">
            {item.year ? `${item.year}` : ""}{runtimeMin ? ` · ${formatRuntime(runtimeMin)}` : ""}{isAudio ? " · áudio" : ""}
            {quality ? ` · ${quality.label}` : ""}
            {subtitles.pt ? " · legendas em português e inglês" : subtitles.en ? " · legenda em inglês" : " · sem legenda"}
          </p>
        </div>

        <div className="ml-auto flex items-center gap-2">
          {episodes.length > 1 ? (
            <Button
              variant="ghost"
              size="icon-sm"
              className="min-h-11 min-w-11"
              aria-label="Próximos episódios"
              aria-pressed={showEpisodes}
              onClick={() => setShowEpisodes((v) => !v)}
            >
              <ListVideo className="size-4" />
            </Button>
          ) : null}

          <Button
            variant="ghost"
            size="icon-sm"
            className="min-h-11 min-w-11"
            aria-label={
              subtitleOptions.length
                ? subtitleLang === "off"
                  ? "Ligar legendas"
                  : `Legendas em ${subtitleLang === "pt" ? "português" : "inglês"} (desligar)`
                : "Sem legendas disponíveis"
            }
            aria-pressed={subtitleLang !== "off"}
            disabled={!subtitleOptions.length}
            onClick={toggleSubtitles}
          >
            {subtitleLang !== "off" ? (
              <Captions className="size-4 text-primary" />
            ) : (
              <CaptionsOff className="size-4" />
            )}
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon-sm" className="min-h-11 min-w-11" aria-label="Qualidade">
                <Settings className="size-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>Qualidade</DropdownMenuLabel>
              {qualities.length > 1 ? (
                <DropdownMenuRadioGroup value={quality?.label ?? ""} onValueChange={changeQuality}>
                  {qualities.map((q) => (
                    <DropdownMenuRadioItem key={q.label} value={q.label}>
                      {q.label}
                    </DropdownMenuRadioItem>
                  ))}
                </DropdownMenuRadioGroup>
              ) : (
                <DropdownMenuItem disabled>
                  {quality ? `${quality.label} (única versão)` : "Sem versões disponíveis"}
                </DropdownMenuItem>
              )}
              <DropdownMenuLabel>Legendas</DropdownMenuLabel>
              {subtitleOptions.length > 0 ? (
                <DropdownMenuRadioGroup
                  value={subtitleLang === "off" ? "off" : subtitleLang}
                  onValueChange={(value) => setSubtitleLang(value as "off" | "pt" | "en")}
                >
                  <DropdownMenuRadioItem value="off">Desligadas</DropdownMenuRadioItem>
                  {subtitleOptions.map((option) => (
                    <DropdownMenuRadioItem key={option.value} value={option.value}>
                      {option.label}
                    </DropdownMenuRadioItem>
                  ))}
                </DropdownMenuRadioGroup>
              ) : (
                <DropdownMenuItem disabled>Este título não tem legenda</DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>

          <Button
            variant="ghost"
            size="icon-sm"
            className="min-h-11 min-w-11"
            aria-label={isFullscreen ? "Sair da tela cheia" : "Tela cheia"}
            onClick={toggleFullscreen}
          >
            {isFullscreen ? <Minimize className="size-4" /> : <Maximize className="size-4" />}
          </Button>

          <Button
            variant="ghost"
            size="icon-sm"
            className="min-h-11 min-w-11"
            aria-label="Fechar player"
            onClick={close}
          >
            <X className="size-4" />
          </Button>
        </div>
      </div>

      <div className="flex min-h-0 flex-1 gap-3 px-2 pb-4">
        <div ref={containerRef} className="relative flex min-w-0 flex-1 items-center justify-center bg-black">
          <video
            ref={videoRef}
            key={`${archiveId}-${quality?.label ?? ""}`}
            src={quality?.url}
            poster={item.posterUrl}
            controls
            autoPlay
            playsInline
            preload="metadata"
            controlsList="nodownload"
            onLoadedMetadata={(event) => {
              const video = event.currentTarget;
              const target = seekToRef.current;
              if (target > 5 && target < video.duration - 5) video.currentTime = target;
              for (const track of Array.from(video.textTracks)) {
                track.mode = trackMatches(track, subtitleLang) ? "showing" : "hidden";
              }
            }}
            onTimeUpdate={(event) => {
              const now = event.currentTarget.currentTime;
              if (Math.abs(now - lastSavedRef.current) < 5) return;
              lastSavedRef.current = now;
              persist();
            }}
            onEnded={() => {
              persist();
              if (nextEpisode) goToEpisode(episodeIndex + 1);
            }}
            onError={() => setFailed(true)}
            onPlaying={() => setFailed(false)}
            className="max-h-full w-full bg-black"
          >
            {subtitles.en ? (
              <track kind="subtitles" srcLang="en" label="Inglês" src={subtitles.en} />
            ) : null}
            {subtitles.pt ? (
              <track kind="subtitles" srcLang="pt-BR" label="Português (BR)" src={subtitles.pt} />
            ) : null}
            Seu navegador não consegue reproduzir este vídeo.
          </video>

          {failed ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-background/90 px-6 text-center">
              <p className="text-sm text-foreground">
                O arquivo não carregou agora. Verifique a conexão e tente de novo.
              </p>
              <Button
                size="sm"
                onClick={() => {
                  setFailed(false);
                  videoRef.current?.load();
                  void videoRef.current?.play();
                }}
              >
                Tentar de novo
              </Button>
            </div>
          ) : null}
        </div>

        {showEpisodes && episodes.length > 1 ? (
          <aside className="hidden w-80 shrink-0 overflow-y-auto rounded-lg border border-border/70 bg-card/80 p-3 md:block">
            <h3 className="font-display text-sm uppercase tracking-wide">Próximos episódios</h3>
            <ul className="mt-3 space-y-2">
              {episodes.map((candidate, index) => (
                <li key={candidate.archiveId}>
                  <button
                    type="button"
                    onClick={() => goToEpisode(index)}
                    className={cn(
                      "w-full rounded-md px-3 py-2 text-left text-sm transition-colors hover:bg-secondary",
                      index === episodeIndex && "bg-secondary text-foreground",
                    )}
                  >
                    <span className="block text-xs uppercase tracking-wide text-muted-foreground">
                      T{candidate.season}:E{candidate.number} · {formatRuntime(candidate.runtimeMin)}
                    </span>
                    <span className="block truncate">{candidate.title}</span>
                  </button>
                </li>
              ))}
            </ul>
          </aside>
        ) : null}
      </div>

      {nextEpisode ? (
        <div className="flex flex-wrap items-center justify-center gap-3 px-4 pb-4 text-xs text-muted-foreground">
          <span>
            A seguir: T{nextEpisode.season}:E{nextEpisode.number} {nextEpisode.title} (
            {formatRuntime(nextEpisode.runtimeMin)})
          </span>
          <Button size="sm" variant="outline" onClick={() => goToEpisode(episodeIndex + 1)}>
            <SkipForward className="size-4" />
            Próximo episódio
          </Button>
        </div>
      ) : (
        <p className="px-4 pb-4 text-center text-xs text-muted-foreground">
          Acervo em domínio público do Internet Archive. Pressione F para tela cheia e Esc para fechar.
          {startPosition ? ` Retomando em ${formatClock(startPosition)}.` : ""}
        </p>
      )}
    </div>
  );
}
