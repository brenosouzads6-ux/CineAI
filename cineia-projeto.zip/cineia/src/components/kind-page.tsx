import { CatalogGrid, ContinueWatchingRow, FeaturedHero } from "@/components/catalog-view";
import { featuredOf, useCatalog, type Kind } from "@/lib/catalog";

export function KindPage({ title, intro, kind }: { title: string; intro: string; kind: Kind }) {
  const { items: all, isLoading } = useCatalog();
  const items = all.filter((i) => i.kind === kind);
  const featured = featuredOf(items);
  return (
    <main className="mx-auto w-full max-w-6xl px-4 pb-20">
      <h1 className="mt-8 font-display text-4xl uppercase tracking-wide">{title}</h1>
      <p className="mt-2 text-sm text-muted-foreground">{intro}</p>
      {featured.length ? <FeaturedHero items={featured} /> : null}
      <div className="mt-12 space-y-12">
        <ContinueWatchingRow kind={kind} />
        <section aria-label={`Todos os ${title.toLowerCase()}`}>
          <h2 className="mb-4 font-display text-2xl uppercase tracking-wide">Catálogo</h2>
          {items.length ? (
            <CatalogGrid items={items} />
          ) : (
            <p className="rounded-lg border border-border/70 bg-card/50 p-6 text-sm text-muted-foreground">
              {isLoading ? "Carregando…" : "Nenhum título por aqui ainda."}
            </p>
          )}
        </section>
      </div>
    </main>
  );
}
