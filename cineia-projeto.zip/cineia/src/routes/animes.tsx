import { createFileRoute } from "@tanstack/react-router";
import { KindPage } from "@/components/kind-page";

export const Route = createFileRoute("/animes")({
  head: () => ({
    meta: [
      { title: "Animes — CineIA" },
      { name: "description", content: "One Piece, SPY x FAMILY, My Hero Academia e JoJo's Bizarre Adventure: Steel Ball Run no catálogo do CineIA." },
      { property: "og:title", content: "Animes — CineIA" },
      { property: "og:description", content: "Os animes que estão chegando ao CineIA." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <KindPage title="Animes" intro="Animes para maratonar episódio por episódio." kind="anime" />
  ),
});
