import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/auth/callback")({
  head: () => ({ meta: [
    { title: "Confirmando entrada — CineIA" },
    { name: "description", content: "Confirmação segura de entrada no painel CineIA." },
    { property: "og:title", content: "Confirmando entrada — CineIA" },
    { property: "og:description", content: "Confirmação de entrada no CineIA." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
    { name: "robots", content: "noindex" },
  ] }),
  component: AuthCallback,
});

function AuthCallback() {
  const navigate = useNavigate();
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    let active = true;
    // The session can take a moment to be stored after Google returns; retry before giving up.
    const tryConfirm = async (attempt: number) => {
      try {
        const { data } = await supabase.auth.getSession();
        if (!active) return;
        if (data.session) { void navigate({ to: "/admin", replace: true }); return; }
      } catch { /* retry below */ }
      if (!active) return;
      if (attempt >= 20) { setFailed(true); return; }
      setTimeout(() => void tryConfirm(attempt + 1), 500);
    };
    void tryConfirm(0);
    return () => { active = false; };
  }, [navigate]);
  return <main className="mx-auto max-w-3xl px-4 py-12">
    <h1 className="font-display text-3xl">{failed ? "Não foi possível confirmar sua entrada" : "Confirmando entrada…"}</h1>
    {failed ? <Button className="mt-6" onClick={() => navigate({ to: "/admin" })}>Voltar ao painel</Button> : null}
  </main>;
}