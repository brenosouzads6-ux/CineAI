import { createFileRoute } from "@tanstack/react-router";
import { KindPage } from "@/components/kind-page";

export const Route = createFileRoute("/desenhos")({
  head: () => ({
    meta: [
      { title: "Desenhos clássicos — CineIA" },
      { name: "description", content: "Superman, Popeye e Betty Boop: desenhos clássicos completos para assistir em sequência." },
      { property: "og:title", content: "Desenhos clássicos — CineIA" },
      { property: "og:description", content: "Curtas animados que marcaram época, um atrás do outro." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <KindPage title="Desenhos" intro="Desenhos para todas as idades." kind="desenho" />
  ),
});
