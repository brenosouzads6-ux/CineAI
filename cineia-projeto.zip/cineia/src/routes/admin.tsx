import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Trash2, Upload, LogOut } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { KIND_LABEL, useCatalog, type Kind } from "@/lib/catalog";
import { isAudioFile, uploadFile } from "@/lib/upload";
import { DriveImport } from "@/components/drive-import";
import { useServerFn } from "@tanstack/react-start";
import { autofillTitle } from "@/lib/autofill.functions";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Painel do dono — CineIA" },
      { name: "description", content: "Painel restrito para adicionar títulos ao CineIA." },
      { property: "og:title", content: "Painel do dono — CineIA" },
      { property: "og:description", content: "Área restrita do CineIA." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminPage,
});

type State = "loading" | "signed-out" | "denied" | "admin";

function AdminPage() {
  const [state, setState] = useState<State>("loading");
  const [email, setEmail] = useState("");

  useEffect(() => {
    let active = true;
    const check = async () => {
      try {
        const { data, error } = await supabase.auth.getUser();
        if (!active) return;
        const user = data.user;
        if (error || !user) return setState("signed-out");
        setEmail(user.email ?? "");
        const { data: ok, error: roleError } = await supabase.rpc("has_role", { _user_id: user.id, _role: "admin" });
        if (!active) return;
        if (roleError) throw roleError;
        setState(ok ? "admin" : "denied");
      } catch {
        if (active) {
          setState("signed-out");
          toast.error("Não foi possível verificar sua entrada. Tente novamente.");
        }
      }
    };
    void check();
    let timer: ReturnType<typeof setTimeout> | undefined;
    const { data: sub } = supabase.auth.onAuthStateChange((event) => {
      // Auth callbacks run inside the session lock. Query only after it is released.
      if (event === "SIGNED_IN" || event === "SIGNED_OUT") {
        clearTimeout(timer);
        timer = setTimeout(() => void check(), 0);
      }
    });
    return () => {
      active = false;
      clearTimeout(timer);
      sub.subscription.unsubscribe();
    };
  }, []);

  return (
    <main className="mx-auto w-full max-w-3xl px-4 pb-20">
      <h1 className="mt-8 font-display text-4xl uppercase tracking-wide">Painel</h1>
      {state === "loading" ? <p className="mt-4 text-sm text-muted-foreground">Carregando…</p> : null}
      {state === "signed-out" ? <SignIn /> : null}
      {state === "denied" ? (
        <div className="mt-6 space-y-3 rounded-lg border border-border/70 bg-card p-6">
          <p className="text-sm">A conta {email} não tem acesso a este painel.</p>
          <Button variant="outline" onClick={() => supabase.auth.signOut()}>Sair</Button>
        </div>
      ) : null}
      {state === "admin" ? (
        <>
          <div className="mt-2 flex items-center gap-3 text-sm text-muted-foreground">
            Conectado como {email}
            <Button variant="ghost" size="sm" onClick={() => supabase.auth.signOut()}>
              <LogOut className="size-4" /> Sair
            </Button>
          </div>
          <AddTitleForm />
          <DriveImport />
          <TitleList />
        </>
      ) : null}
    </main>
  );
}

function SignIn() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
      if (error) toast.error("Não foi possível entrar", { description: "Confira seu e-mail e senha. Você também pode entrar com Google." });
    } catch {
      toast.error("Não foi possível conectar. Tente novamente.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mt-6 space-y-4 rounded-lg border border-border/70 bg-card p-6">
      <p className="text-sm text-muted-foreground">Área restrita. Entre com a conta do dono.</p>
      <Button
        className="w-full"
        variant="outline"
        disabled={busy}
        onClick={async () => {
          setBusy(true);
          try {
            const r = await lovable.auth.signInWithOAuth("google", {
              redirect_uri: `${window.location.origin}/auth/callback`,
              extraParams: { prompt: "select_account" },
            });
            if (r.error) toast.error("Falha no login com Google", { description: String(r.error.message ?? r.error) });
          } catch {
            toast.error("Não foi possível abrir o Google. Tente novamente.");
          } finally {
            setBusy(false);
          }
        }}
      >
        Entrar com Google
      </Button>
      <form onSubmit={submit} className="space-y-3">
        <div className="space-y-1">
          <Label htmlFor="email">E-mail</Label>
          <Input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div className="space-y-1">
          <Label htmlFor="senha">Senha</Label>
          <Input id="senha" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
        </div>
        <Button type="submit" className="w-full" disabled={busy}>
          {busy ? "Entrando…" : "Entrar"}
        </Button>
      </form>
    </div>
  );
}

function AddTitleForm() {
  const qc = useQueryClient();
  const { items } = useCatalog();
  const [target, setTarget] = useState<string>("new");
  const [kind, setKind] = useState<Kind>("filme");
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState("");
  const [filling, setFilling] = useState(false);
  const autofill = useServerFn(autofillTitle);

  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);
    const files = (fd.getAll("arquivos") as File[]).filter((f) => f.size > 0);
    if (!files.length) {
      toast.error("Escolha pelo menos um arquivo de vídeo ou MP3.");
      return;
    }
    setBusy(true);
    try {
      let titleId = target;
      let startNumber = 1;
      let season = Number(fd.get("temporada") || 1);
      if (target === "new") {
        const poster = fd.get("capa") as File;
        const posterPath = poster && poster.size ? await uploadFile(poster, "capas") : null;
        const { data, error } = await supabase
          .from("catalog_titles")
          .insert({
            kind,
            title: String(fd.get("titulo")),
            year: fd.get("ano") ? Number(fd.get("ano")) : null,
            genres: String(fd.get("generos") || "").split(",").map((g) => g.trim()).filter(Boolean),
            synopsis: String(fd.get("sinopse") || ""),
            poster_url: posterPath,
            featured: fd.get("destaque") === "on",
          })
          .select("id")
          .single();
        if (error) throw error;
        titleId = data.id;
      } else {
        const existing = items.find((i) => i.id === target);
        const same = (existing?.episodes ?? []).filter((ep) => ep.season === season);
        startNumber = same.length ? Math.max(...same.map((ep) => ep.number)) + 1 : 1;
        if (existing?.kind === "filme") season = 1;
      }
      for (const [i, file] of files.entries()) {
        setProgress(`Enviando ${i + 1} de ${files.length}: ${file.name} — 0%`);
        const path = await uploadFile(file, "arquivos", (p) =>
          setProgress(`Enviando ${i + 1} de ${files.length}: ${file.name} — ${p}%`),
        );
        const { error } = await supabase.from("catalog_episodes").insert({
          title_id: titleId,
          season,
          number: startNumber + i,
          name: files.length > 1 || kind !== "filme" ? file.name.replace(/\.[^.]+$/, "") : "",
          media_url: path,
          media_type: isAudioFile(file) ? "audio" : "video",
        });
        if (error) throw error;
      }
      toast.success("Título adicionado ao catálogo");
      form.reset();
      setTarget("new");
      await qc.invalidateQueries({ queryKey: ["catalog"] });
    } catch (err) {
      toast.error("Não foi possível salvar", { description: err instanceof Error ? err.message : String(err) });
    } finally {
      setBusy(false);
      setProgress("");
    }
  };

  const select = "h-10 w-full rounded-md border border-input bg-background px-3 text-sm";

  const onFiles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    const form = e.target.form;
    if (!file || !form || target !== "new") return;
    const set = (name: string, value: string) => {
      const el = form.elements.namedItem(name) as HTMLInputElement | HTMLTextAreaElement | null;
      if (el && value) el.value = value;
    };
    setFilling(true);
    try {
      const r = await autofill({ data: { fileName: file.name, kind: KIND_LABEL[kind] } });
      set("titulo", r.title);
      set("ano", r.year ? String(r.year) : "");
      set("generos", r.genres.join(", "));
      set("sinopse", r.synopsis);
      toast.success("Nome, gênero e sinopse preenchidos. Confira antes de salvar.");
    } catch (err) {
      set("titulo", file.name.replace(/\.[^.]+$/, "").replace(/[._-]+/g, " ").trim());
      toast.error("Não deu para preencher tudo", { description: err instanceof Error ? err.message : undefined });
    } finally {
      setFilling(false);
    }
  };

  return (
    <form onSubmit={submit} className="mt-6 space-y-4 rounded-lg border border-border/70 bg-card p-6">
      <h2 className="font-display text-2xl uppercase tracking-wide">Adicionar</h2>
      <div className="space-y-1">
        <Label htmlFor="destino">Adicionar a</Label>
        <select id="destino" className={select} value={target} onChange={(e) => setTarget(e.target.value)}>
          <option value="new">Novo título</option>
          {items.map((i) => (
            <option key={i.id} value={i.id}>
              Mais episódios em: {i.title} ({KIND_LABEL[i.kind]})
            </option>
          ))}
        </select>
      </div>

      {target === "new" ? (
        <>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1">
              <Label htmlFor="tipo">Aba</Label>
              <select id="tipo" className={select} value={kind} onChange={(e) => setKind(e.target.value as Kind)}>
                {(Object.keys(KIND_LABEL) as Kind[]).map((k) => (
                  <option key={k} value={k}>{KIND_LABEL[k]}</option>
                ))}
              </select>
            </div>
            <div className="space-y-1">
              <Label htmlFor="ano">Ano</Label>
              <Input id="ano" name="ano" type="number" min={1880} max={2100} />
            </div>
          </div>
          <div className="space-y-1">
            <Label htmlFor="titulo">Título</Label>
            <Input id="titulo" name="titulo" required />
          </div>
          <div className="space-y-1">
            <Label htmlFor="generos">Gêneros (separados por vírgula)</Label>
            <Input id="generos" name="generos" placeholder="Ação, Comédia" />
          </div>
          <div className="space-y-1">
            <Label htmlFor="sinopse">Sinopse</Label>
            <Textarea id="sinopse" name="sinopse" rows={3} />
          </div>
          <div className="space-y-1">
            <Label htmlFor="capa">Capa (imagem)</Label>
            <Input id="capa" name="capa" type="file" accept="image/*" />
          </div>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" name="destaque" /> Mostrar nos destaques
          </label>
        </>
      ) : null}

      <div className="grid gap-3 sm:grid-cols-[1fr_120px]">
        <div className="space-y-1">
          <Label htmlFor="arquivos">Arquivos (MP4, MP3 ou outro vídeo/áudio — vários viram episódios)</Label>
          <Input id="arquivos" name="arquivos" type="file" multiple accept="video/*,audio/*,.mp3,.mp4,.mkv,.webm,.m4a" onChange={onFiles} />
        </div>
        <div className="space-y-1">
          <Label htmlFor="temporada">Temporada</Label>
          <Input id="temporada" name="temporada" type="number" min={1} defaultValue={1} />
        </div>
      </div>

      {filling ? <p className="text-xs text-primary">Preenchendo nome, gênero e sinopse com IA…</p> : null}
      {progress ? <p className="text-xs text-muted-foreground">{progress}</p> : null}
      <Button type="submit" disabled={busy || filling}>
        <Upload className="size-4" /> {busy ? "Enviando…" : "Salvar"}
      </Button>
    </form>
  );
}

function TitleList() {
  const qc = useQueryClient();
  const { items } = useCatalog();
  const remove = async (id: string, title: string) => {
    if (!window.confirm(`Apagar "${title}" do catálogo?`)) return;
    const { error } = await supabase.from("catalog_titles").delete().eq("id", id);
    if (error) {
      toast.error("Não foi possível apagar", { description: error.message });
      return;
    }
    toast.success("Título apagado");
    await qc.invalidateQueries({ queryKey: ["catalog"] });
  };
  return (
    <section className="mt-8">
      <h2 className="font-display text-2xl uppercase tracking-wide">Catálogo ({items.length})</h2>
      <ul className="mt-3 divide-y divide-border/70 rounded-lg border border-border/70 bg-card">
        {items.map((i) => (
          <li key={i.id} className="flex items-center gap-3 p-3">
            <img src={i.posterUrl} alt="" className="h-14 w-10 rounded object-cover" />
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium">{i.title}</p>
              <p className="text-xs text-muted-foreground">
                {KIND_LABEL[i.kind]} · {i.episodes ? `${i.episodes.length} episódio(s)` : i.mediaType === "audio" ? "áudio" : "vídeo"}
              </p>
            </div>
            <Button variant="ghost" size="icon-sm" aria-label={`Apagar ${i.title}`} onClick={() => remove(i.id, i.title)}>
              <Trash2 className="size-4" />
            </Button>
          </li>
        ))}
        {!items.length ? <li className="p-4 text-sm text-muted-foreground">Nenhum título ainda.</li> : null}
      </ul>
    </section>
  );
}
