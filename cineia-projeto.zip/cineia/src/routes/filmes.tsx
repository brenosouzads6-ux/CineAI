import { createFileRoute } from "@tanstack/react-router";
import { KindPage } from "@/components/kind-page";

export const Route = createFileRoute("/filmes")({
  head: () => ({
    meta: [
      { title: "Filmes para assistir — CineIA" },
      { name: "description", content: "Filmes completos para assistir no navegador pelo CineIA." },
      { property: "og:title", content: "Filmes para assistir — CineIA" },
      { property: "og:description", content: "Filmes completos, do início ao fim, no CineIA." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => <KindPage title="Filmes" intro="Filmes completos para assistir do início ao fim." kind="filme" />,
});
