import { createFileRoute } from "@tanstack/react-router";
import { KindPage } from "@/components/kind-page";

export const Route = createFileRoute("/series")({
  head: () => ({
    meta: [
      { title: "Séries clássicas completas — CineIA" },
      { name: "description", content: "Séries completas para assistir episódio por episódio no CineIA." },
      { property: "og:title", content: "Séries clássicas completas — CineIA" },
      { property: "og:description", content: "Maratone séries clássicas episódio por episódio." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <KindPage title="Séries" intro="Séries completas, com o próximo episódio já engatilhado." kind="serie" />
  ),
});
