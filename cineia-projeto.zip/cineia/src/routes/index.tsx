import { createFileRoute } from "@tanstack/react-router";
import { ContinueWatchingRow, FeaturedHero, MediaRow } from "@/components/catalog-view";
import { featuredOf, useCatalog, type Kind } from "@/lib/catalog";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "CineIA — filmes, séries, animes e desenhos para assistir" },
      { name: "description", content: "Assista filmes, séries, animes e desenhos no navegador, com continuar assistindo e próximos episódios." },
      { property: "og:title", content: "CineIA — filmes, séries, animes e desenhos" },
      { property: "og:description", content: "Assista no navegador, sem cadastro." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

const ROWS: { kind: Kind; title: string; subtitle: string }[] = [
  { kind: "filme", title: "Filmes", subtitle: "Do início ao fim" },
  { kind: "serie", title: "Séries", subtitle: "Episódio por episódio" },
  { kind: "anime", title: "Animes", subtitle: "Para maratonar" },
  { kind: "desenho", title: "Desenhos", subtitle: "Para todas as idades" },
];

function Home() {
  const { items, isLoading } = useCatalog();
  return (
    <main className="mx-auto w-full max-w-6xl px-4 pb-20">
      <h1 className="sr-only">CineIA — assistir filmes, séries, animes e desenhos</h1>
      <FeaturedHero items={featuredOf(items)} />
      <div className="mt-12 space-y-12">
        <ContinueWatchingRow />
        {ROWS.map((r) => (
          <MediaRow key={r.kind} row={{ title: r.title, subtitle: r.subtitle, items: items.filter((i) => i.kind === r.kind) }} />
        ))}
        {!isLoading && !items.length ? (
          <p className="mt-10 rounded-lg border border-border/70 bg-card/50 p-6 text-center text-sm text-muted-foreground">
            O catálogo está vazio por enquanto. Novos títulos chegam em breve.
          </p>
        ) : null}
      </div>
    </main>
  );
}
