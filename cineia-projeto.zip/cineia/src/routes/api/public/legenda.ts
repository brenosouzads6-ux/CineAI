import { createFileRoute } from "@tanstack/react-router";

/**
 * Repassa o arquivo de legenda do acervo com o tipo correto (text/vtt),
 * já que o servidor original o entrega como texto puro e sem CORS.
 */
export const Route = createFileRoute("/api/public/legenda")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const id = url.searchParams.get("id") ?? "";
        const file = url.searchParams.get("file") ?? "";

        if (!/^[A-Za-z0-9._-]+$/.test(id) || !file.toLowerCase().endsWith(".vtt")) {
          return new Response("Parâmetros inválidos", { status: 400 });
        }

        const source = `https://archive.org/download/${id}/${encodeURIComponent(file)}`;
        const upstream = await fetch(source, { redirect: "follow" });
        if (!upstream.ok) {
          return new Response("Legenda indisponível", { status: 502 });
        }

        const text = await upstream.text();
        const body = text.trimStart().startsWith("WEBVTT") ? text : `WEBVTT\n\n${text}`;

        return new Response(body, {
          headers: {
            "content-type": "text/vtt; charset=utf-8",
            "cache-control": "public, max-age=86400",
          },
        });
      },
    },
  },
});
