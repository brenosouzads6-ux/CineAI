import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { isMediaName, safeName } from "@/lib/upload";

// Leitura e importação de arquivos do Google Drive do dono (conector google_drive,
// via connector gateway). Somente admins.

const GATEWAY = "https://connector-gateway.lovable.dev/google_drive/drive/v3";

function gatewayHeaders() {
  const apiKey = process.env["LOVABLE_API_KEY"];
  const connKey = process.env["GOOGLE_DRIVE_API_KEY"];
  if (!apiKey || !connKey) throw new Error("A conexão com o Google Drive não está ativa.");
  return { Authorization: `Bearer ${apiKey}`, "X-Connection-Api-Key": connKey };
}

export type DriveFolder = { id: string; name: string };
export type DriveFile = { id: string; name: string; mimeType: string; size: number };

async function driveGet(path: string) {
  const res = await fetch(`${GATEWAY}${path}`, { headers: gatewayHeaders() });
  if (!res.ok) {
    const detail = await res.text().catch(() => "");
    throw new Error(`O Drive respondeu com erro ${res.status}. ${detail.slice(0, 200)}`);
  }
  return res.json() as Promise<{ files?: { id: string; name: string; mimeType?: string; size?: string }[]; nextPageToken?: string }>;
}

export const listDriveFolders = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<{ folders: DriveFolder[] }> => {
    const { data: ok } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
    if (!ok) throw new Error("Sem permissão");
    const q = "mimeType='application/vnd.google-apps.folder' and trashed=false";
    const folders: DriveFolder[] = [];
    let pageToken: string | undefined;
    do {
      const url = `/files?q=${encodeURIComponent(q)}&pageSize=200&fields=nextPageToken,files(id,name)&orderBy=name`;
      const body = await driveGet(pageToken ? `${url}&pageToken=${pageToken}` : url);
      for (const f of body.files ?? []) folders.push({ id: f.id, name: f.name });
      pageToken = body.nextPageToken;
    } while (pageToken);
    return { folders };
  });

export const listDriveFiles = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({ folderId: z.string().regex(/^[A-Za-z0-9_-]+$/), all: z.boolean().optional() }).parse(d),
  )
  .handler(async ({ data, context }): Promise<{ files: DriveFile[] }> => {
    const { data: ok } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
    if (!ok) throw new Error("Sem permissão");
    const q = `'${data.folderId}' in parents and trashed=false`;
    const files: DriveFile[] = [];
    let pageToken: string | undefined;
    do {
      const url = `/files?q=${encodeURIComponent(q)}&pageSize=200&fields=nextPageToken,files(id,name,mimeType,size)&orderBy=name`;
      const body = await driveGet(pageToken ? `${url}&pageToken=${pageToken}` : url);
      for (const f of body.files ?? []) {
        files.push({ id: f.id, name: f.name, mimeType: f.mimeType ?? "", size: Number(f.size ?? 0) });
      }
      pageToken = body.nextPageToken;
    } while (pageToken);
    const media = files.filter((f) => isMediaName(f.name, f.mimeType));
    return { files: data.all ? files : media };
  });

// Baixa um arquivo do Drive (streaming) e guarda direto no acervo do app, sem
// passar o arquivo inteiro pela memória do servidor. Depois cria o episódio.
export const importDriveFile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z
      .object({
        fileId: z.string().regex(/^[A-Za-z0-9_-]+$/),
        fileName: z.string().min(1).max(300),
        mimeType: z.string().max(150).optional(),
        titleId: z.string().uuid(),
        season: z.number().int().min(1),
        episodeNumber: z.number().int().min(1),
        episodeName: z.string().max(300).optional(),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const { data: ok } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
    if (!ok) throw new Error("Sem permissão");

    const audio = (data.mimeType ?? "").startsWith("audio/") || /\.(mp3|m4a|wav|ogg|aac|flac|opus)$/i.test(data.fileName);
    const down = await fetch(`${GATEWAY}/files/${data.fileId}?alt=media`, {
      headers: { ...gatewayHeaders(), Accept: "*/*" },
    });
    if (!down.ok || !down.body) {
      const detail = await down.text().catch(() => "");
      throw new Error(`Não consegui baixar "${data.fileName}" do Drive (${down.status}). ${detail.slice(0, 200)}`);
    }

    const path = `arquivos/${crypto.randomUUID()}-${safeName(data.fileName)}`;
    const storageUrl = `${process.env["SUPABASE_URL"]}/storage/v1/object/midia/${path}`;
    const up = await fetch(storageUrl, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env["SUPABASE_SERVICE_ROLE_KEY"]}`,
        "Content-Type": data.mimeType || (audio ? "audio/mpeg" : "video/mp4"),
        "x-upsert": "true",
        "Cache-Control": "3600",
      },
      body: down.body,
      duplex: "half",
    } as RequestInit & { duplex: "half" });
    if (!up.ok) {
      await down.body.cancel().catch(() => {});
      const detail = await up.text().catch(() => "");
      throw new Error(`Não consegui guardar "${data.fileName}" (${up.status}). ${detail.slice(0, 200)}`);
    }

    const { error } = await context.supabase.from("catalog_episodes").insert({
      title_id: data.titleId,
      season: data.season,
      number: data.episodeNumber,
      name: data.episodeName ?? "",
      media_url: path,
      media_type: audio ? "audio" : "video",
    });
    if (error) throw new Error(error.message);
    return { ok: true as const, path };
  });
