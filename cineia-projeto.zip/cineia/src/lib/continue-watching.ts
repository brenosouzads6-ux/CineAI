import { useEffect, useState } from "react";

/** Onde o usuário parou em cada filme ou episódio (salvo no próprio navegador). */
export type WatchProgress = {
  key: string;
  itemId: string;
  archiveId: string;
  episodeIndex: number;
  position: number;
  duration: number;
  updatedAt: number;
};

const STORAGE_KEY = "cineia:continuar-assistindo";
const EVENT = "cineia:progresso";

export const progressKey = (itemId: string, archiveId: string) => `${itemId}::${archiveId}`;

function readAll(): Record<string, WatchProgress> {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as Record<string, WatchProgress>) : {};
  } catch {
    return {};
  }
}

function writeAll(data: Record<string, WatchProgress>) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    /* espaço cheio ou modo privativo: segue sem salvar */
  }
  window.dispatchEvent(new Event(EVENT));
}

export function saveProgress(entry: Omit<WatchProgress, "key" | "updatedAt">) {
  if (!entry.duration || entry.position < 10) return;
  const key = progressKey(entry.itemId, entry.archiveId);
  const all = readAll();
  // Quase no fim: considera assistido e tira da fila.
  if (entry.position / entry.duration > 0.97) {
    delete all[key];
  } else {
    all[key] = { ...entry, key, updatedAt: Date.now() };
  }
  writeAll(all);
}

export function getProgress(itemId: string, archiveId: string) {
  return readAll()[progressKey(itemId, archiveId)];
}

export function removeProgress(key: string) {
  const all = readAll();
  delete all[key];
  writeAll(all);
}

export function listProgress(): WatchProgress[] {
  return Object.values(readAll()).sort((a, b) => b.updatedAt - a.updatedAt);
}

/** Lista reativa de "continuar assistindo". */
export function useContinueWatching() {
  const [items, setItems] = useState<WatchProgress[]>([]);

  useEffect(() => {
    const sync = () => setItems(listProgress());
    sync();
    window.addEventListener(EVENT, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(EVENT, sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  return items;
}
