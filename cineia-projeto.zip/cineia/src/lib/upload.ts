// Utilitários de envio de arquivos para o bucket "midia" (lado do navegador).

export const safeName = (name: string) => name.normalize("NFD").replace(/[^\w.-]+/g, "_");

const AUDIO_EXT = /\.(mp3|m4a|wav|ogg|aac|flac|opus)$/i;
const VIDEO_EXT = /\.(mp4|mkv|webm|mov|avi|m4v)$/i;

export const isAudioFile = (f: { name: string; type?: string }) =>
  (f.type ?? "").startsWith("audio/") || AUDIO_EXT.test(f.name);

export const isMediaName = (name: string, mimeType: string) =>
  mimeType.startsWith("video/") ||
  mimeType.startsWith("audio/") ||
  AUDIO_EXT.test(name) ||
  VIDEO_EXT.test(name);

// Envio em pedaços de 6MB (retomável): arquivos grandes não ficam inteiros na memória do celular.
export async function uploadFile(file: File, folder: string, onPct?: (p: number) => void) {
  const path = `${folder}/${crypto.randomUUID()}-${safeName(file.name)}`;
  const { supabase } = await import("@/integrations/supabase/client");
  const { data } = await supabase.auth.getSession();
  const token = data.session?.access_token;
  if (!token) throw new Error("Sessão expirada. Entre de novo.");
  const { Upload } = await import("tus-js-client");
  await new Promise<void>((resolve, reject) => {
    const up = new Upload(file, {
      endpoint: `${import.meta.env["VITE_SUPABASE_URL"]}/storage/v1/upload/resumable`,
      retryDelays: [0, 3000, 5000, 10000, 20000],
      headers: {
        authorization: `Bearer ${token}`,
        apikey: import.meta.env["VITE_SUPABASE_PUBLISHABLE_KEY"],
        "x-upsert": "true",
      },
      uploadDataDuringCreation: true,
      removeFingerprintOnSuccess: true,
      chunkSize: 6 * 1024 * 1024,
      metadata: {
        bucketName: "midia",
        objectName: path,
        contentType: file.type || "application/octet-stream",
        cacheControl: "3600",
      },
      onError: (e) => reject(new Error("Falha no envio: " + (e.message || "conexão"))),
      onProgress: (sent, total) => onPct?.(total ? Math.round((sent / total) * 100) : 0),
      onSuccess: () => resolve(),
    });
    up.start();
  });
  return path;
}
