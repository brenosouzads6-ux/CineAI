import { ARCHIVE_FILES } from "./archive-files";
import { PT_SUBTITLES } from "./subtitle-langs";

/** Arquivo de vídeo direto do acervo. */
export const archiveUrl = (archiveId: string, file: string) =>
  `https://archive.org/download/${archiveId}/${encodeURIComponent(file)}`;

/** Imagem de capa do acervo. */
export const archivePoster = (archiveId: string) => `https://archive.org/services/img/${archiveId}`;

export type Quality = { label: string; url: string; height: number };

/** Versões de qualidade realmente existentes para um título. */
export function qualitiesFor(archiveId: string): Quality[] {
  const entry = ARCHIVE_FILES[archiveId];
  if (!entry) return [];
  const seen = new Set<string>();
  const list: Quality[] = [];
  for (const video of entry.videos) {
    const label = video.height > 0 ? `${video.height}p` : "Padrão";
    if (seen.has(label)) continue;
    seen.add(label);
    list.push({ label, url: archiveUrl(archiveId, video.file), height: video.height });
  }
  return list;
}

/** Qualidade inicial: a melhor até 720p, para começar rápido. */
export function defaultQuality(list: Quality[]): Quality | undefined {
  return list.find((q) => q.height > 0 && q.height <= 720) ?? list[list.length - 1] ?? list[0];
}

/**
 * Legendas servidas como arquivos estáticos do próprio app (o original do
 * acervo não tem cabeçalhos que o navegador aceite em <track>).
 * PT-BR só existe quando a tradução foi concluída para o título.
 */
export type SubtitleTracks = { en?: string; pt?: string };

export function subtitlesFor(archiveId: string): SubtitleTracks {
  const tracks: SubtitleTracks = {};
  if (ARCHIVE_FILES[archiveId]?.subtitle) {
    tracks.en = `/legendas/${archiveId}.en.vtt`;
    if (PT_SUBTITLES.has(archiveId)) {
      tracks.pt = `/legendas/${archiveId}.pt.vtt`;
    }
  }
  return tracks;
}

export const formatRuntime = (min: number) =>
  min >= 60 ? `${Math.floor(min / 60)}h ${String(min % 60).padStart(2, "0")}min` : `${min}min`;

export const formatClock = (seconds: number) => {
  const total = Math.max(0, Math.floor(seconds));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const mm = String(m).padStart(2, "0");
  const ss = String(s).padStart(2, "0");
  return h > 0 ? `${h}:${mm}:${ss}` : `${m}:${ss}`;
};
