import { queryOptions, useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type Kind = "filme" | "serie" | "anime" | "desenho";

export type Episode = {
  /** Identificador usado para salvar o progresso. */
  archiveId: string;
  season: number;
  number: number;
  title: string;
  runtimeMin: number;
  mediaUrl?: string;
  mediaType?: "video" | "audio";
};

export type MediaItem = {
  id: string;
  kind: Kind;
  title: string;
  year: number;
  genres: string[];
  synopsis: string;
  posterUrl: string;
  tagline?: string;
  runtimeMin?: number;
  /** Filmes: identificador do arquivo. */
  archiveId?: string;
  mediaUrl?: string;
  mediaType?: "video" | "audio";
  episodes?: Episode[];
  featured?: boolean;
  playable: boolean;
  unavailableNote?: string;
};

export type Row = { title: string; subtitle: string; items: MediaItem[] };

export const KIND_LABEL: Record<Kind, string> = {
  filme: "Filme",
  serie: "Série",
  anime: "Anime",
  desenho: "Desenho",
};

const FALLBACK_POSTER =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 400"><rect width="300" height="400" fill="#2a2620"/><text x="150" y="210" font-family="sans-serif" font-size="28" fill="#d9a441" text-anchor="middle">CineIA</text></svg>',
  );

export const catalogQuery = queryOptions({
  queryKey: ["catalog"],
  staleTime: 1000 * 60 * 30,
  queryFn: async (): Promise<MediaItem[]> => {
    const { data, error } = await supabase
      .from("catalog_titles")
      .select("*, catalog_episodes(*)")
      .order("created_at", { ascending: false });
    if (error) throw error;
    const paths = new Set<string>();
    for (const t of data ?? []) {
      if (t.poster_url && !t.poster_url.startsWith("http")) paths.add(t.poster_url);
      for (const e of t.catalog_episodes ?? []) if (!e.media_url.startsWith("http")) paths.add(e.media_url);
    }
    const signed = new Map<string, string>();
    if (paths.size) {
      const { data: urls } = await supabase.storage.from("midia").createSignedUrls([...paths], 60 * 60 * 12);
      for (const u of urls ?? []) if (u.path && u.signedUrl) signed.set(u.path, u.signedUrl);
    }
    const resolve = (v: string | null) => (v ? (v.startsWith("http") ? v : (signed.get(v) ?? "")) : "");
    return (data ?? []).map((t) => {
      const eps = [...(t.catalog_episodes ?? [])].sort((a, b) => a.season - b.season || a.number - b.number);
      const episodes: Episode[] = eps.map((e) => ({
        archiveId: e.id,
        season: e.season,
        number: e.number,
        title: e.name || `Episódio ${e.number}`,
        runtimeMin: 0,
        mediaUrl: resolve(e.media_url),
        mediaType: e.media_type as "video" | "audio",
      }));
      const base: MediaItem = {
        id: t.id,
        kind: t.kind as Kind,
        title: t.title,
        year: t.year ?? 0,
        genres: t.genres ?? [],
        synopsis: t.synopsis,
        posterUrl: resolve(t.poster_url) || FALLBACK_POSTER,
        featured: t.featured,
        playable: episodes.length > 0,
        unavailableNote: "Ainda não há arquivo para este título.",
      };
      if (t.kind === "filme") {
        const first = episodes[0];
        return first
          ? { ...base, archiveId: first.archiveId, mediaUrl: first.mediaUrl ?? "", mediaType: first.mediaType ?? "video" }
          : base;
      }
      return { ...base, episodes };
    });
  },
});

export const useCatalog = () => {
  const { data = [], isLoading } = useQuery(catalogQuery);
  return { items: data, isLoading };
};

export const episodeCount = (item: MediaItem) => item.episodes?.length ?? 0;

export const featuredOf = (items: MediaItem[]) => {
  const playable = items.filter((i) => i.playable);
  const marked = playable.filter((i) => i.featured);
  return (marked.length ? marked : playable).slice(0, 6);
};
