import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type AutofillResult = { title: string; year: number | null; genres: string[]; synopsis: string };

export const autofillTitle = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ fileName: z.string().min(1).max(300), kind: z.string().max(20) }).parse(d))
  .handler(async ({ data, context }): Promise<AutofillResult> => {
    const { data: ok } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
    if (!ok) throw new Error("Sem permissão");
    const { generateResponse, GatewayError } = await import("@lovable.dev/ai-gateway");
    try {
      const res = await generateResponse({
        model: "openai/gpt-6-astra",
        reasoning: { effort: "low" },
        input: [
          {
            role: "user",
            content: `Nome do arquivo enviado: "${data.fileName}". Tipo: ${data.kind}.
Identifique a obra (filme, série, anime, desenho ou música). Responda em português do Brasil com: título oficial em PT-BR (ou original se não houver), ano (ou null), até 3 gêneros e uma sinopse curta (2-3 frases, sem spoilers). Se não reconhecer, crie um título limpo a partir do nome do arquivo e deixe sinopse vazia.`,
          },
        ],
        text: {
          format: {
            type: "json_schema",
            name: "titulo",
            strict: true,
            schema: {
              type: "object",
              additionalProperties: false,
              required: ["title", "year", "genres", "synopsis"],
              properties: {
                title: { type: "string" },
                year: { type: ["integer", "null"] },
                genres: { type: "array", items: { type: "string" } },
                synopsis: { type: "string" },
              },
            },
          },
        },
      });
      let text = "";
      for (const item of res.output ?? []) {
        if (item.type === "message") for (const c of item.content) if (c.type === "output_text") text += c.text;
      }
      return JSON.parse(text) as AutofillResult;
    } catch (e) {
      if (e instanceof GatewayError && e.httpStatus === 402) throw new Error("Crédito de IA esgotado");
      throw new Error("Não foi possível preencher automaticamente");
    }
  });
