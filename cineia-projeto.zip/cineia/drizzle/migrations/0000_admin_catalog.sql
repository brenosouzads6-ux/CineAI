DO $$ BEGIN CREATE TYPE public.app_role AS ENUM ('admin','user'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role public.app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own roles readable" ON public.user_roles FOR SELECT TO authenticated USING (user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE OR REPLACE FUNCTION public.grant_owner_admin()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF lower(NEW.email) = 'brenosouzads6@gmail.com' THEN
    INSERT INTO public.user_roles(user_id, role) VALUES (NEW.id, 'admin') ON CONFLICT DO NOTHING;
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS on_auth_user_owner_admin ON auth.users;
CREATE TRIGGER on_auth_user_owner_admin AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.grant_owner_admin();

INSERT INTO public.user_roles(user_id, role)
SELECT id, 'admin' FROM auth.users WHERE lower(email) = 'brenosouzads6@gmail.com'
ON CONFLICT DO NOTHING;

CREATE TABLE public.catalog_titles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kind text NOT NULL CHECK (kind IN ('filme','serie','anime','desenho')),
  title text NOT NULL,
  year int,
  genres text[] NOT NULL DEFAULT '{}',
  synopsis text NOT NULL DEFAULT '',
  poster_url text,
  featured boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.catalog_titles TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.catalog_titles TO authenticated;
GRANT ALL ON public.catalog_titles TO service_role;
ALTER TABLE public.catalog_titles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "catalog public read" ON public.catalog_titles FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "admin write titles" ON public.catalog_titles FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

CREATE TABLE public.catalog_episodes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title_id uuid NOT NULL REFERENCES public.catalog_titles(id) ON DELETE CASCADE,
  season int NOT NULL DEFAULT 1,
  number int NOT NULL DEFAULT 1,
  name text NOT NULL DEFAULT '',
  media_url text NOT NULL,
  media_type text NOT NULL DEFAULT 'video' CHECK (media_type IN ('video','audio')),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.catalog_episodes TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.catalog_episodes TO authenticated;
GRANT ALL ON public.catalog_episodes TO service_role;
ALTER TABLE public.catalog_episodes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "episodes public read" ON public.catalog_episodes FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "admin write episodes" ON public.catalog_episodes FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

CREATE POLICY "midia public read" ON storage.objects FOR SELECT USING (bucket_id = 'midia');
CREATE POLICY "midia admin insert" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'midia' AND public.has_role(auth.uid(),'admin'));
CREATE POLICY "midia admin update" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = 'midia' AND public.has_role(auth.uid(),'admin'));
CREATE POLICY "midia admin delete" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'midia' AND public.has_role(auth.uid(),'admin'));