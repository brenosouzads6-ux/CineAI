CREATE TABLE public.chat_messages (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  client_message_id text,
  role text NOT NULL CHECK (role IN ('user','assistant','system')),
  parts jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX chat_messages_user_created_idx ON public.chat_messages (user_id, created_at);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chat_messages TO authenticated;
GRANT ALL ON public.chat_messages TO service_role;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own chat messages" ON public.chat_messages FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TABLE public.titles (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  slug text NOT NULL UNIQUE,
  name text NOT NULL,
  year integer,
  kind text NOT NULL DEFAULT 'filme',
  genres text[] NOT NULL DEFAULT '{}',
  synopsis text NOT NULL DEFAULT '',
  rating numeric(3,1),
  platforms text[] NOT NULL DEFAULT '{}',
  poster_path text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.titles TO authenticated;
GRANT SELECT ON public.titles TO anon;
GRANT ALL ON public.titles TO service_role;
ALTER TABLE public.titles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "titles readable by everyone" ON public.titles FOR SELECT USING (true);
CREATE POLICY "authenticated can add titles" ON public.titles FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "authenticated can update titles" ON public.titles FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.list_items (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  title_slug text NOT NULL REFERENCES public.titles(slug) ON DELETE CASCADE,
  list_kind text NOT NULL CHECK (list_kind IN ('favorite','watchlist')),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, title_slug, list_kind)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.list_items TO authenticated;
GRANT ALL ON public.list_items TO service_role;
ALTER TABLE public.list_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own list items" ON public.list_items FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE POLICY "posters readable by authenticated" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'posters');